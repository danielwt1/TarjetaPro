package com.ejemplo.tarjeta.tarjetapro.security;

import com.ejemplo.tarjeta.tarjetapro.models.Credencial;
import com.ejemplo.tarjeta.tarjetapro.repository.CredencialRepository;
import com.ejemplo.tarjeta.tarjetapro.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
@Service
//clase numero 2 que toca crear
public class JwtUserDetailsService implements UserDetailsService {

    private UserRepository userRepo;
    private CredencialRepository credencialRepository;
    @Autowired
    public JwtUserDetailsService(UserRepository userRepo,CredencialRepository credencialRepository) {
        this.userRepo = userRepo;
        this.credencialRepository = credencialRepository;
    }

    @Override
    public UserDetails loadUserByUsername(String username) {
        Credencial credencial = this.credencialRepository.findOneByUser(username).orElseThrow(()-> new UsernameNotFoundException("men"));

        List<GrantedAuthority> roles = new ArrayList<>();
        //String role = credencial.getUsuarioId().getRoles()
        credencial.getUsuarioId().getRoles().forEach(rol ->{
            roles.add(new SimpleGrantedAuthority(rol.getRolName()));
        });
        // de la clase de spring import org.springframework.security.core.userdetail
        return new User(username,credencial.getPassword(),roles);
    }
}
