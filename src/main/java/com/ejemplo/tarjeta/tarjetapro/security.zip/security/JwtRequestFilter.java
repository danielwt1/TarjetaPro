package com.ejemplo.tarjeta.tarjetapro.security;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

//CLASE 5 QUE TOCA CREAR
@Component
//Intercepta las peticione spara ver si el token es adecuado
public class JwtRequestFilter extends OncePerRequestFilter {

    @Autowired
    JwtUserDetailsService jwtUserDetailsService;
    @Autowired
    JWTokenUtil jwTokenUtil;


    @Override
    protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain) throws ServletException, IOException {
        final  String tokenHeader = request.getHeader("Authorization");
        String username = "";
        String tokenJwt = "";
        if(tokenHeader != null){
            if(tokenHeader.startsWith("Bearer ") || tokenHeader.startsWith("bearer ")){
                tokenJwt = tokenHeader.substring(7);// es en 7 porque el token empieza a partir de la pos 7 por el espacio
                username = jwTokenUtil.getUserNameFromToken(tokenJwt);
            }
        if(username.isEmpty()){
            UserDetails userDetails = this.jwtUserDetailsService.loadUserByUsername(username);
            if(jwTokenUtil.validateToken(tokenJwt,userDetails)){
                //el nullo es por el password
                UsernamePasswordAuthenticationToken userPassAuthToken = new UsernamePasswordAuthenticationToken(username,
                        null,userDetails.getAuthorities());
            }
        }
        }
    }
}
