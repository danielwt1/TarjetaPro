package com.ejemplo.tarjeta.tarjetapro.security;
//Clase 4
public class JwtResponse {
    private final String token;

    public JwtResponse(String token) {
        this.token = token;
    }

    public String getToken() {
        return token;
    }
}
