package com.ejemplo.tarjeta.tarjetapro.security;


//Clase primera para crear la logica de JWT
// se agrega dependencia en el pom JWT
// SI estoy trabajando en un jdk superior al 11 debo agregar al pom las depéndencias de jaakrta

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Component;

import java.time.LocalDate;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;
import java.util.function.Function;
import java.util.stream.Collectors;
//Clase 1 que toca crear esta es la primera para manipular y generar token

/**
 * <dependency>
 * <groupId>org.glassfish.jaxb</groupId>
 * <artifactId>jaxb-runtime</artifactId>
 * </dependency>
 *
 * <dependency>
 * <groupId>org.springframework.boot</groupId>
 * <artifactId>spring-boot-starter-security</artifactId>
 * </dependency>*
 */

@Component
public class JWTokenUtil {
    public final long JWT_TOKEN_VALIDITY = 5 * 60 * 60 * 1000;//tiempo de valides del token // 5 h
    @Value("${jwt.secret}")
    private String secret;

    //Metodo que genera el Token
    //UserDetails Interfaz de springSecurity para expresar detalles, informacion de roles
    public String generateToken(UserDetails userDetails) {
        // Aca genero el payload se maneja  como un Object
        Map<String, Object> claims = new HashMap<>();
        //obtener rol y ingresarlo en el map para que este en el token
        claims.put("role", userDetails.getAuthorities().stream().map(GrantedAuthority::getAuthority).collect(Collectors.joining()));
        claims.put("test", "Hola prueba");
        return doGenerateToken(claims, userDetails.getUsername());
    }

    //Metodo que se encarga de recibir el usuario y subject el subject es quien genero la peticion
    // El metodo genera el Token
    public String doGenerateToken(Map<String, Object> claims, String subject) {
        return Jwts.builder()
                .setClaims(claims)
                .setSubject(subject)
                .setIssuedAt(new Date(System.currentTimeMillis()))
                //fecha actual + la constante para vencimiento en mmilis
                .setExpiration(new Date(System.currentTimeMillis() + JWT_TOKEN_VALIDITY))
                // firma del token
                //Para hacer el encriptado del token
                .signWith(SignatureAlgorithm.HS256, secret)
                //Generar token como spring
                .compact();
    }

    //Metodo que valida token ??
    public Claims getAllClaimsFromToken(String token) {
        return Jwts.parser().setSigningKey(secret).parseClaimsJws(token).getBody();
    }

    public <T> T getClaimFromToken(String token, Function<Claims, T> claimsResolver) {
        final Claims claims = getAllClaimsFromToken(token);
        return claimsResolver.apply(claims);
    }

    //Ver mitocode ep 1 para ver otros metodos de utilidad
    //get usuername from token
    public String getUserNameFromToken(String token) {
        return getClaimFromToken(token, Claims::getSubject);
    }

    //Metodo para recuperar fecha del token
    public Date getExpirationFromToken(String token) {
        return getClaimFromToken(token, Claims::getExpiration);
    }

    //metodo que dice si el topken expiro
    public boolean isTokenValid(String token) {
        final Date expiration = getExpirationFromToken(token);
        return expiration.before(new Date());
    }

    //Ver si el token es vigente
    public boolean validateToken(String token, UserDetails userDetails) {
        final String username = getUserNameFromToken(token);
        return (username.equalsIgnoreCase(userDetails.getUsername()) && !isTokenValid(token));
    }


}
